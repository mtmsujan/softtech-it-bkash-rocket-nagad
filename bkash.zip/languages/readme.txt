Translations have moved to
https://translate.wordpress.org/projects/wp-plugins/bkash

Thank you for your contribution.